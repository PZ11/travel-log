# Log Entry

* Title - Text
* Description - Text
* Comments - Text
* Rating - scale of 1 - 10
* Image - Text - URL
* Latitude - Number
* Longitude - Number
* Created At - DateTime
* Updated At - DateTime
